/*GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007/<MCT>  Copyright (C) Mon Apr  3 07:01:31 AM PDT 2023 shaynababe
This program comes with ABSOLUTELY NO WARRANTY; for details type pnpm install.
This is free software, and you are welcome to redistribute it 
under certain conditions; type pnpm start for details.<MCT>  Copyright (C) Mon Apr  3 07:01:31 AM PDT 2023 shaynababe */


<template>
<div
    ref="TagEditor"
    class="c-tag-applier"
>
    <TagSelection
        v-for="(addedTag, index) in addedTags"
        :key="index"
        :class="{ 'w-tag-wrapper--tag-selector' : addedTag.newTag }"
        :selected-tag="addedTag.newTag ? null : addedTag"
        :new-tag="addedTag.newTag"
        :added-tags="addedTags"
        @tagRemoved="tagRemoved"
        @tagAdded="tagAdded"
    />
    <button
        v-show="!userAddingTag && !maxTagsAdded"
        class="c-tag-applier__add-btn c-icon-button c-icon-button--major icon-plus"
        title="Add new tag"
        @click="addTag"
    >
        <div class="c-icon-button__label c-tag-btn__label">Add Tag</div>
    </button>
</div>
</template>

<script>
import TagSelection from './TagSelection.vue';

export default {
    components: {
        TagSelection
    },
    inject: ['openmct'],
    props: {
        annotations: {
            type: Array,
            required: true
        },
        annotationType: {
            type: String,
            required: false,
            default: null
        },
        domainObject: {
            type: Object,
            required: true,
            default: null
        },
        targets: {
            type: Object,
            required: true,
            default: null
        },
        targetDomainObjects: {
            type: Object,
            required: true,
            default: null
        },
        onTagChange: {
            type: Function,
            required: false,
            default: null
        }
    },
    data() {
        return {
            addedTags: [],
            userAddingTag: false
        };
    },
    computed: {
        availableTags() {
            return this.openmct.annotation.getAvailableTags();
        },
        maxTagsAdded() {
            const availableTags = this.openmct.annotation.getAvailableTags();

            return !(availableTags && availableTags.length && (this.addedTags.length < availableTags.length));
        }
    },
    watch: {
        annotations: {
            handler() {
                this.annotationsChanged();
            },
            deep: true
        }
    },
    mounted() {
        this.annotationsChanged();
    },
    destroyed() {
        document.body.removeEventListener('click', this.tagCanceled);
    },
    methods: {
        annotationsChanged() {
            if (this.annotations) {
                this.tagsChanged();
            }
        },
        annotationDeletionListener(changedAnnotation) {
            const matchingAnnotation = this.annotations.find((possibleMatchingAnnotation) => {
                return this.openmct.objects.areIdsEqual(possibleMatchingAnnotation.identifier, changedAnnotation.identifier);
            });
            if (matchingAnnotation) {
                matchingAnnotation._deleted = changedAnnotation._deleted;
                this.userAddingTag = false;
                this.tagsChanged();
            }
        },
        tagsChanged() {
            // gather tags from annotations
            const tagsFromAnnotations = this.annotations.flatMap((annotation) => {
                if (annotation._deleted) {
                    return [];
                } else {
                    return annotation.tags;
                }
            }).filter((tag, index, array) => {
                return array.indexOf(tag) === index;
            });

            if (tagsFromAnnotations.length !== this.addedTags.length) {
                this.addedTags = this.addedTags.slice(0, tagsFromAnnotations.length);
            }

            for (let index = 0; index < tagsFromAnnotations.length; index += 1) {
                this.$set(this.addedTags, index, tagsFromAnnotations[index]);
            }
        },
        addTag() {
            const newTagValue = {
                newTag: true
            };
            this.addedTags.push(newTagValue);
            this.userAddingTag = true;
            document.body.addEventListener('click', this.tagCanceled);
        },
        async tagRemoved(tagToRemove) {
            // Soft delete annotations that match tag instead (that aren't already deleted)
            const annotationsToDelete = this.annotations.filter((annotation) => {
                return annotation.tags.includes(tagToRemove) && !annotation._deleted;
            });
            if (annotationsToDelete) {
                await this.openmct.annotation.deleteAnnotations(annotationsToDelete);
                this.$emit('tags-updated', annotationsToDelete);
                if (this.onTagChange) {
                    this.userAddingTag = false;
                    this.onTagChange(this.annotations);
                }
            }
        },
        tagCanceled(event) {
            if (this.$refs.TagEditor) {
                const clickedInsideTagEditor = this.$refs.TagEditor.contains(event.target);
                if (!clickedInsideTagEditor) {
                    // Hide TagSelection and show "Add Tag" button
                    this.userAddingTag = false;
                    this.tagsChanged();
                }
            }
        },
        async tagAdded(newTag) {
            // Either undelete an annotation, or create one (1) new annotation
            let existingAnnotation = this.annotations.find((annotation) => {
                return annotation.tags.includes(newTag);
            });

            if (!existingAnnotation) {
                const contentText = `${this.annotationType} tag`;
                const annotationCreationArguments = {
                    name: contentText,
                    existingAnnotation,
                    contentText: contentText,
                    targets: this.targets,
                    targetDomainObjects: this.targetDomainObjects,
                    domainObject: this.domainObject,
                    annotationType: this.annotationType,
                    tags: [newTag]
                };
                existingAnnotation = await this.openmct.annotation.create(annotationCreationArguments);
            } else if (existingAnnotation._deleted) {
                this.openmct.annotation.unDeleteAnnotation(existingAnnotation);
            }

            this.userAddingTag = false;
            document.body.removeEventListener('click', this.tagCanceled);

            this.$emit('tags-updated', existingAnnotation);
            if (this.onTagChange) {
                this.onTagChange([existingAnnotation]);
            }
        }
    }
};
</script>
