// map.js
module.exports = testFile => testFile.replace(/\.test\.js$/, '.js')
