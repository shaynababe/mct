// @create-index

export { default as PropertiesViewProvider } from './PropertiesViewProvider.js';

