// @create-index

export { default as inspector } from './inspector';

