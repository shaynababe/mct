// @create-index

export { default as StaticModelProvider } from './StaticModelProvider.js';
export { default as StaticModelProviderSpec } from './StaticModelProviderSpec.js';
export { default as plugin } from './plugin.js';

