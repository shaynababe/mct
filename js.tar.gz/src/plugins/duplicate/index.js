// @create-index

export { default as DuplicateAction } from './DuplicateAction.js';
export { default as DuplicateTask } from './DuplicateTask.js';
export { default as plugin } from './plugin.js';
export { default as pluginSpec } from './pluginSpec.js';

