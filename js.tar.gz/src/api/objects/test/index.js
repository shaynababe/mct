// @create-index

export { default as RootObjectProviderSpec } from './RootObjectProviderSpec.js';
export { default as RootRegistrySpec } from './RootRegistrySpec.js';

