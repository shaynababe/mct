export default class ConflictError extends Error {
}
