// @create-index

export { default as InspectorDetailsSpec } from './InspectorDetailsSpec.js';
export { default as InspectorStylesSpec } from './InspectorStylesSpec.js';
export { default as InspectorStylesSpecMocks } from './InspectorStylesSpecMocks.js';

