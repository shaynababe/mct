// @create-index

export { default as GrandSearchSpec } from './GrandSearchSpec.js';

