// @create-index

export { default as InspectorViewRegistry } from './InspectorViewRegistry.js';
export { default as ToolbarRegistry } from './ToolbarRegistry.js';
export { default as ViewRegistry } from './ViewRegistry.js';

