// @create-index

export { default as mockLocalStorage } from './mockLocalStorage.js';

