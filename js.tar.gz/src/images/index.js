// @create-index

export { default as favicons } from './favicons';

