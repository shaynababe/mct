// @create-index

export { default as plugin } from './plugin.js';

